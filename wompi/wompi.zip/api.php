<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $transaction_id = $_POST['transaction_id'];

    if (isset($_FILES['comprobante'])) {
        $upload_dir = 'comprobantes/';
        $file_path = $upload_dir . basename($_FILES['comprobante']['name']);

        if (move_uploaded_file($_FILES['comprobante']['tmp_name'], $file_path)) {
            // Guardar informaci�n del pago
            file_put_contents('pagos.txt', "ID: $transaction_id, Email: $email, Comprobante: $file_path\n", FILE_APPEND);
            http_response_code(200);
        } else {
            http_response_code(500);
        }
    } else {
        http_response_code(400);
    }
} else {
    http_response_code(405);
}
?>
